package sk.stuba.fei.uim.oop.board;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.gui.Colors;

import javax.swing.*;
import java.awt.*;

public class BentPipe extends Tile {
    private final Board board;
    @Setter @Getter
    private Direction direction;

    public BentPipe(int row, int col, Board board) {
        super(row, col, board);
        this.board = board;
        this.setType(Type.BENT);
        this.setConnected(false);
        setPreferredSize(new Dimension(50, 50));
        this.setBorder(BorderFactory.createLineBorder(Colors.LIGHT_GRAY));
        this.addMouseListener(this);
        setBackground(Colors.WHITE);
        randomDirection();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (this.isConnected()){g.setColor(Colors.BLUE);}
        else g.setColor(Colors.BLACK);
        ((Graphics2D) g).setStroke(new BasicStroke(10));

        switch (direction) {
            case UP:
                g.drawLine(getWidth()/2, getHeight() / 2, getWidth()/2, -getHeight());
                g.drawLine(getWidth() / 2, getHeight() / 2, getWidth(), getHeight() / 2);
                this.setConnectionOne(Direction.UP);
                this.setConnectionTwo(Direction.RIGHT);
                this.board.repaint();
                this.direction = Direction.UP;
                break;
            case RIGHT:
                g.drawLine(getWidth() / 2, getHeight() / 2, getWidth(), getHeight() / 2);
                g.drawLine(getWidth() / 2, getHeight() / 2, getWidth() / 2, getHeight());
                this.setConnectionOne(Direction.RIGHT);
                this.setConnectionTwo(Direction.DOWN);
                this.board.repaint();
                this.direction = Direction.RIGHT;
                break;
            case DOWN:
                g.drawLine(0, getHeight() / 2, getWidth()/2, getHeight() / 2);
                g.drawLine(getWidth() / 2, getHeight() / 2, getWidth() / 2, getHeight());
                this.setConnectionOne(Direction.DOWN);
                this.setConnectionTwo(Direction.LEFT);
                this.board.repaint();
                this.direction = Direction.DOWN;
                break;
            case LEFT:
                g.drawLine(0, getHeight() / 2, getWidth()/2, getHeight() / 2);
                g.drawLine(getWidth() / 2, getHeight() / 2, getWidth() / 2, -getHeight());
                this.setConnectionOne(Direction.LEFT);
                this.setConnectionTwo(Direction.UP);
                this.board.repaint();
                this.direction = Direction.LEFT;
                break;
        }
    }

    private void randomDirection(){
        int random = (int) (Math.random() * 4);
        switch (random) {
            case 0:
                this.direction = Direction.UP;
                break;
            case 1:
                this.direction = Direction.RIGHT;
                break;
            case 2:
                this.direction = Direction.DOWN;
                break;
            case 3:
                this.direction = Direction.LEFT;
                break;
        }
    }
}
