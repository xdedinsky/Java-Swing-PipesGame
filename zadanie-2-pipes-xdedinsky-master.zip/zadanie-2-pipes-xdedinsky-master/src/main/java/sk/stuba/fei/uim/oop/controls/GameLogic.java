package sk.stuba.fei.uim.oop.controls;

import lombok.Getter;
import sk.stuba.fei.uim.oop.board.Board;
import sk.stuba.fei.uim.oop.gui.Game;
import sk.stuba.fei.uim.oop.board.*;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public class GameLogic extends UniversalAdapter {
    private final JFrame frame;
    private final Board board;
    @Getter
    private JLabel boardSizeLabel;
    private int boardSize;
    @Getter
    private JLabel levelLabel;
    private int level;

    public GameLogic(JFrame frame) {
        this.frame = frame;
        this.boardSize = 8;
        this.level = 1;
        this.boardSizeLabel = new JLabel();
        this.levelLabel = new JLabel();
        this.board = new Board(boardSize);
        this.frame.add(board);
        this.frame.setFocusable(true);
    }

    private void updateLabels(){
        boardSizeLabel.setText("Board size: " + boardSize + "x" + boardSize);
        levelLabel.setText("Level: " + level);
    }

    private void winCheck() {
        ArrayList<Tile> way = new ArrayList<>();
        way.add(board.getStart());
        Tile tile;
        Tile neighbor;
        Direction neighborDirection;

        while (way.get(way.size()-1) != board.getEnd()) {

            tile = way.get(way.size()-1);
            if (tile == null){return;}
            tile.setConnected(true);
            neighbor = tile.getNeighborFromConnection(tile.getConnectionOne());

            for (Tile tileTemp : way){
                if (neighbor == tileTemp){
                    neighbor = tile.getNeighborFromConnection(tile.getConnectionTwo());
                    break;
                }
            }
            for (Tile tileTemp : way){
                if (neighbor == tileTemp){
                    return;
                }
            }

            if(neighbor == null || neighbor.type == Type.EMPTY){return;}
            if(neighbor.getRow() == board.getEnd().getRow() && neighbor.getCol() == board.getEnd().getCol()){
                if(checkEndConnected(tile)){
                    level = level+1;
                    restart();
                }
                return;
            }
            neighborDirection = tile.getNeighborDirection(neighbor);
            if(!neighbor.isPipeConnected(tile.getConnectionOne(), tile.getConnectionTwo(), neighborDirection)){return;}
            way.add(neighbor);
        }
    }

    private boolean checkEndConnected(Tile neighbor) {
        Direction connectionEnd = board.getEnd().getConnectionOne();
        if (connectionEnd == Direction.UP && (neighbor.getConnectionOne() == Direction.DOWN || neighbor.getConnectionTwo() == Direction.DOWN)){
            return Type.END == neighbor.getNeighborFromConnection(Direction.DOWN).getType();
        }
        if (connectionEnd == Direction.RIGHT && (neighbor.getConnectionOne() == Direction.LEFT ||neighbor.getConnectionTwo() == Direction.LEFT)){
            return Type.END == neighbor.getNeighborFromConnection(Direction.LEFT).getType();
        }
        if (connectionEnd == Direction.DOWN && (neighbor.getConnectionOne() == Direction.UP ||neighbor.getConnectionTwo() == Direction.UP)){
            return Type.END == neighbor.getNeighborFromConnection(Direction.UP).getType();
        }
        if (connectionEnd == Direction.LEFT && (neighbor.getConnectionOne() == Direction.RIGHT ||neighbor.getConnectionTwo() == Direction.RIGHT)) {
            return Type.END == neighbor.getNeighborFromConnection(Direction.RIGHT).getType();
        }
        return false;
    }

    public void restart() {
        updateLabels();
        board.initializeBoard();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_ESCAPE: frame.dispose(); System.exit(0); break;
            case KeyEvent.VK_R: level = 1; restart(); break;
            case KeyEvent.VK_ENTER: this.winCheck(); break;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case Game.BUTTON_RESTART:
                level = 1;
                restart();
                break;
            case Game.BUTTON_CHECK:
                winCheck();
                break;
            default:
                break;
        }
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        int size = ((JSlider) e.getSource()).getValue();
        if ((size != boardSize && size % 2 == 0)) {
            level = 1;
            boardSize = size;
            restart();
        }
    }
}

