package sk.stuba.fei.uim.oop.board;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.gui.Colors;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Board extends JPanel {
    @Getter @Setter
    private Tile[][] tiles;
    @Getter @Setter
    private Tile start,end;
    @Getter @Setter
    private ArrayList<Tile> way;
    private final List<Direction> directions;
    private final int size;

    public Board(int size) {
        this.size = size;
        way = new ArrayList<>();
        directions = new ArrayList<>();
        directions.add(Direction.UP);
        directions.add(Direction.RIGHT);
        directions.add(Direction.DOWN);
        directions.add(Direction.LEFT);
        initializeBoard();
    }

    public void initializeBoard(){
        this.removeAll();
        this.setLayout(new GridLayout(size, size));
        this.tiles = new Tile[size][size];
        this.setLayout(new GridLayout(size, size));
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                this.tiles[i][j] = new TileEmpty(i,j, this);
                this.add(this.tiles[i][j]);
            }
        }
        way.clear();
        makeStartEnd();
        way = findWay();
        this.revalidate();
    }

    private void makeStartEnd() {
        int startRow = (int) (Math.random() * this.getTiles().length);
        int endRow = (int) (Math.random() * this.getTiles().length);

        this.getTiles()[startRow][0].setBorder(BorderFactory.createLineBorder(Colors.GREEN, 5));
        this.getTiles()[endRow][this.getTiles()[0].length-1].setBorder(BorderFactory.createLineBorder(Colors.RED, 5));
        this.getTiles()[startRow][0].type = Type.START;
        this.getTiles()[endRow][this.getTiles()[0].length-1].type = Type.END;

        this.setStart(this.getTiles()[startRow][0]);
        this.setEnd(this.getTiles()[endRow][this.getTiles()[0].length-1]);
    }

    private ArrayList<Tile> findWay() {
        this.getWay().clear();
        Tile start = this.getStart();
        Tile end = this.getEnd();
        this.getWay().add(start);
        dfs(start, end);

        setPipesInWay();
        makeBoardWithPipes();
        return this.getWay();
    }

    private void dfs(Tile start, Tile end) {
        start.setVisited(true);
        if (start == end) {
            return;
        }

        Tile neighbor = getRandomNeighborForDFS(start);
        if (neighbor != null) {
            this.getWay().add(neighbor);
            dfs(neighbor, end);
        } else {
            this.getWay().remove(this.getWay().size()-1);
            dfs(this.getWay().get(this.getWay().size()-1), end);
        }
    }

    private Tile getRandomNeighborForDFS(Tile tile) {
        int y = tile.getCol();
        int x = tile.getRow();
        Collections.shuffle(directions);

        for (Direction d : directions) {
            switch (d) {
                case UP:
                    if (x > 0 && !this.getTiles()[x-1][y].isVisited()) {
                        return this.getTiles()[x-1][y];
                    }
                    break;
                case RIGHT:
                    if (x < this.getTiles().length-1 && !this.getTiles()[x+1][y].isVisited()) {
                        return this.getTiles()[x+1][y];
                    }
                    break;
                case DOWN:
                    if (y > 0 && !this.getTiles()[x][y-1].isVisited()) {
                        return this.getTiles()[x][y-1];
                    }
                    break;
                case LEFT:
                    if (y < this.getTiles()[0].length-1 && !this.getTiles()[x][y+1].isVisited()) {
                        return this.getTiles()[x][y+1];
                    }
                    break;
            }
        }
        return null;
    }

    private void setPipesInWay(){
        Tile tilePrev;
        Tile tileMid;
        Tile tileNext;

        for (int i = 0; i < this.getWay().size()-2; i++){
            tilePrev = this.getWay().get(i);
            tileMid = this.getWay().get(i+1);
            tileNext = this.getWay().get(i+2);
            if ((tilePrev.getRow() == tileMid.getRow() && tileMid.getRow() == tileNext.getRow()) || (tilePrev.getCol() == tileMid.getCol() && tileMid.getCol() == tileNext.getCol())){
                this.getWay().remove(i+1);
                this.getWay().add(i+1, new StraightPipe(tileMid.getRow(), tileMid.getCol(), this));
            }else{
                this.getWay().remove(i+1);
                this.getWay().add(i+1, new BentPipe(tileMid.getRow(), tileMid.getCol(), this));
            }
        }
    }

    private void makeBoardWithPipes(){
        this.removeAll();
        this.setTiles(new Tile[this.getTiles().length][this.getTiles().length]);
        boolean condition = false;

        for (int i = 0; i < this.getTiles().length; i++) {
            for (int j = 0; j < this.getTiles().length; j++) {
                for (Tile tile : this.getWay()) {
                    if (tile.getRow() == i && tile.getCol() == j) {
                        this.getTiles()[i][j] = tile;
                        this.add(this.getTiles()[i][j]);
                        condition = true;
                    }
                }
                if (!condition) {
                    this.getTiles()[i][j] = new TileEmpty(i, j, this);
                    this.add(this.getTiles()[i][j]);
                }
                condition = false;
            }
        }

        this.getWay().get(0).type = Type.START;
        this.getWay().get(this.getWay().size()-1).type = Type.END;
        this.revalidate();
        this.setVisible(true);
    }
}
