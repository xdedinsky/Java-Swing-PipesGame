package sk.stuba.fei.uim.oop.board;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT;

    public Direction next() {
        if (this == UP) return RIGHT;
        else if (this == RIGHT) return DOWN;
        else if (this == DOWN) return LEFT;
        else return UP;
    }
}
