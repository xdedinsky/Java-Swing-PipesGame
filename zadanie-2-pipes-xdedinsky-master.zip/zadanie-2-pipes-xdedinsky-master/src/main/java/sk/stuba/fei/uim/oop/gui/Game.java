package sk.stuba.fei.uim.oop.gui;

import java.awt.*;
import javax.swing.*;

import sk.stuba.fei.uim.oop.controls.GameLogic;

public class Game {
    public static final String BUTTON_RESTART = "RESTART!";
    public static final String BUTTON_CHECK = "CHECK!";
    public Game() {
        JFrame frame = new JFrame("Water Pipes Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 850);
        frame.setLayout(new BorderLayout());
        frame.setResizable(false);
        frame.setFocusable(true);
        frame.requestFocusInWindow();
        
        GameLogic gameLogic = new GameLogic(frame);

        JPanel panelMenu = new JPanel();
        panelMenu.setLayout(new GridLayout(2,3));
        panelMenu.add(gameLogic.getLevelLabel());

        JButton restartButton = new JButton(BUTTON_RESTART);
        restartButton.addActionListener(gameLogic);
        restartButton.setFocusable(false);
        panelMenu.add(restartButton);

        JButton checkButton = new JButton(BUTTON_CHECK);
        checkButton.addActionListener(gameLogic);
        checkButton.setFocusable(false);
        panelMenu.add(checkButton);

        panelMenu.add(gameLogic.getBoardSizeLabel());
        gameLogic.restart();

        JSlider slider = new JSlider(JSlider.HORIZONTAL, 8, 12, 8);
        slider.setMajorTickSpacing(2);
        slider.setPaintLabels(true);
        slider.setSnapToTicks(true);
        slider.setFocusable(false);
        slider.addChangeListener(gameLogic);
        panelMenu.add(slider);

        frame.addKeyListener(gameLogic);
        frame.add(panelMenu, BorderLayout.PAGE_END);
        frame.setVisible(true);
    }
}
