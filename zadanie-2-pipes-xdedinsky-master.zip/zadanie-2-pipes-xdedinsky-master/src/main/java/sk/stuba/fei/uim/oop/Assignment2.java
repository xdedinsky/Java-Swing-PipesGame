package sk.stuba.fei.uim.oop;

import sk.stuba.fei.uim.oop.gui.Game;

public class Assignment2 {
    public static void main(String[] args) {new Game();}
}
