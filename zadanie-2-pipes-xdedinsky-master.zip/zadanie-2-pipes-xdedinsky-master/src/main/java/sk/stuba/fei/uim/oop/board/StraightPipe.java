package sk.stuba.fei.uim.oop.board;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.gui.Colors;

import javax.swing.*;
import java.awt.*;

public class StraightPipe extends Tile {
    @Getter @Setter
    private boolean horizontal;
    private final Board board;

    public StraightPipe(int row, int col, Board board) {
        super(row, col, board);
        this.setType(Type.STRAIGHT);
        this.horizontal = Math.random() < 0.5;
        this.setConnected(false);
        this.board = board;
        setBackground(Colors.WHITE);
        setPreferredSize(new Dimension(50, 50));
        setBorder(BorderFactory.createLineBorder(Colors.LIGHT_GRAY));
        this.addMouseListener(this);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (this.isConnected()){g.setColor(Colors.BLUE);}
        else g.setColor(Colors.BLACK);

        ((Graphics2D) g).setStroke(new BasicStroke(10));
        if (horizontal){
            g.drawLine(0, getHeight() / 2, getWidth(), getHeight() / 2);
            this.setConnectionOne(Direction.LEFT);
            this.setConnectionTwo(Direction.RIGHT);
        } else {
            g.drawLine(getWidth() / 2, 0, getWidth() / 2, getHeight());
            this.setConnectionOne(Direction.UP);
            this.setConnectionTwo(Direction.DOWN);
        }
        this.board.repaint();
    }
}
