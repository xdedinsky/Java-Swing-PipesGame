package sk.stuba.fei.uim.oop.board;

import lombok.Getter;
import lombok.Setter;

import sk.stuba.fei.uim.oop.gui.Colors;

import java.awt.*;
import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public abstract class Tile extends JPanel implements MouseListener {
    @Getter @Setter
    protected int row;
    @Getter @Setter
    protected int col;
    @Getter @Setter
    protected boolean connected;
    @Getter @Setter
    protected boolean visited;
    @Getter @Setter
    public Type type;
    protected Board board;
    @Getter @Setter
    protected Direction connectionOne, connectionTwo;

    public Tile(int row, int col, Board board) {
        this.row = row;
        this.col = col;
        this.setVisited(false);
        this.board = board;
        setPreferredSize(new Dimension(50, 50));
        this.setBorder(BorderFactory.createLineBorder(Colors.WHITE));
    }

    public void deleteDesignAllTiles(){
        for (int i = 0; i < board.getTiles().length; i++) {
            for (int j = 0; j < board.getTiles()[i].length; j++) {
                if (board.getTiles()[i][j] != null && !(board.getTiles()[i][j].type == Type.START) && !(board.getTiles()[i][j].type == Type.END)) {
                    board.getTiles()[i][j].setBackground(Colors.WHITE);
                    board.getTiles()[i][j].setBorder(BorderFactory.createLineBorder(Colors.LIGHT_GRAY));
                    board.getTiles()[i][j].setConnected(false);
                }
            }
        }
        board.getStart().setConnected(false);
    }

    public Direction getNeighborDirection(Tile neighbor) {
        if (neighbor.getRow() < this.getRow()){
            return Direction.UP;
        }
        else if (neighbor.getRow() > this.getRow()){
            return Direction.DOWN;
        }
        else if (neighbor.getCol() < this.getCol()){
            return Direction.LEFT;
        }
        else {
            return Direction.RIGHT;
        }
    }

    public boolean isPipeConnected(Direction connectionOne, Direction connectionTwo, Direction neighborDirection) {

        if ((connectionOne == Direction.UP || connectionTwo == Direction.UP) && (neighborDirection == Direction.UP)){
            if (this.getConnectionOne() == Direction.DOWN || this.getConnectionTwo() == Direction.DOWN){
                return true;
            }
        }
        if ((connectionOne == Direction.RIGHT || connectionTwo == Direction.RIGHT) && neighborDirection == Direction.RIGHT) {
            if (this.getConnectionOne() == Direction.LEFT || this.getConnectionTwo() == Direction.LEFT){
                return true;
            }
        }
        if ((connectionOne == Direction.DOWN || connectionTwo == Direction.DOWN) && neighborDirection == Direction.DOWN){
            if (this.getConnectionOne() == Direction.UP || this.getConnectionTwo() == Direction.UP) {
                return true;
            }
        }
        if ((connectionOne == Direction.LEFT || connectionTwo == Direction.LEFT) && neighborDirection == Direction.LEFT) {
            return this.getConnectionOne() == Direction.RIGHT || this.getConnectionTwo() == Direction.RIGHT;
        }
        return false;
    }

    public Tile getNeighborFromConnection(Direction connection){
        switch (connection) {
            case UP:
                if (this.row > 0) {
                    return board.getTiles()[this.row-1][this.col];
                }
                break;
            case RIGHT:
                if (this.getCol() < board.getTiles().length-1) {
                    return board.getTiles()[this.row][this.col+1];
                }
                break;
            case DOWN:
                if (this.row < board.getTiles().length-1) {
                    return board.getTiles()[this.row+1][this.col];
                }
            case LEFT:
                if (this.getCol() > 0) {
                    return board.getTiles()[this.row][this.col-1];
                }
                break;
        }
        return null;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (this.type == Type.START || this.type == Type.END || this.type == Type.EMPTY){
            return;
        }
        if (this instanceof BentPipe){
            ((BentPipe)this).setDirection(((BentPipe)this).getDirection().next());
        }
        if (this instanceof StraightPipe){
            ((StraightPipe)this).setHorizontal(!((StraightPipe)this).isHorizontal());
        }
        deleteDesignAllTiles();
        board.repaint();
        setBorder(BorderFactory.createLineBorder(Colors.BLACK));
        setBackground(Colors.LIGHT_GRAY);
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {
        if (!(this.type == Type.START || this.type == Type.END)){
            setBorder(BorderFactory.createLineBorder(Colors.LIGHT_GRAY));
            setBackground(Colors.WHITE);
        }
        else{
            this.setBackground(Colors.WHITE);
            if (this.type == Type.START){
                this.setBorder(BorderFactory.createLineBorder(Colors.GREEN,4));
            }
            else{
                this.setBorder(BorderFactory.createLineBorder(Colors.RED,4));
            }
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if (!(this.type == Type.START || this.type == Type.END)){
            setBorder(BorderFactory.createLineBorder(Colors.BLACK));
            setBackground(Colors.LIGHT_GRAY);
        }
        else{
            this.setBackground(Colors.LIGHT_GRAY);
            if (this.type == Type.START){
                this.setBorder(BorderFactory.createLineBorder(Colors.GREEN,12));
            }
            else{
                this.setBorder(BorderFactory.createLineBorder(Colors.RED,12));
            }
        }
    }
}

