package sk.stuba.fei.uim.oop.gui;

import java.awt.*;

public class Colors {
    public static final Color GREEN = new Color(0, 255, 0);
    public static final Color RED = new Color(255, 0, 0);
    public static final Color BLACK = new Color(0, 0, 0);
    public static final Color WHITE = new Color(255, 255, 255);
    public static final Color LIGHT_GRAY = new Color(192, 192, 192);
    public static final Color BLUE = new Color(0, 0, 255);
}
