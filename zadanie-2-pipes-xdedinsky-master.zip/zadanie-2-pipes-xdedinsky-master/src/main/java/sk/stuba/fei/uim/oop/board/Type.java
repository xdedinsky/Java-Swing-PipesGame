package sk.stuba.fei.uim.oop.board;

public enum Type {
    BENT,
    STRAIGHT,
    EMPTY,
    START,
    END
}
