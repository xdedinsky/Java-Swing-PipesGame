package sk.stuba.fei.uim.oop.board;

import sk.stuba.fei.uim.oop.gui.Colors;

import javax.swing.*;
import java.awt.*;

public class TileEmpty extends Tile {
    private final Board board;

    public TileEmpty(int row, int col, Board board) {
        super(row, col, board);
        this.setRow(row);
        this.setCol(col);
        this.type = Type.EMPTY;
        this.board = board;
        setPreferredSize(new Dimension(50, 50));
        this.setBorder(BorderFactory.createLineBorder(Colors.WHITE));
        this.addMouseListener(this);
        setBackground(Colors.WHITE);
        setBorder(BorderFactory.createLineBorder(Colors.LIGHT_GRAY));
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        int radius = 30;
        int waySize = board.getWay().size();

        if (this.type == Type.START) {
            if (this.isConnected()){g.setColor(Colors.BLUE);}
            else g.setColor(Colors.BLACK);
            ((Graphics2D) g).setStroke(new BasicStroke(10));
            drawStartEndConnection(g, connectedDirectionStartEnd(board.getWay().get(0), board.getWay().get(1)));
            g.setColor(Colors.GREEN);
            g.fillOval(getWidth() / 2 - radius / 2, getHeight() / 2 - radius / 2, radius, radius);

        }
        if (this.type == Type.END) {
            g.setColor(Colors.BLACK);
            ((Graphics2D) g).setStroke(new BasicStroke(10));
            drawStartEndConnection(g, connectedDirectionStartEnd(board.getWay().get(waySize - 1), board.getWay().get(waySize - 2)));
            g.setColor(Colors.RED);
            g.fillOval(getWidth() / 2 - radius / 2, getHeight() / 2 - radius / 2, radius, radius);
        }
    }

    private void drawStartEndConnection(Graphics g, Direction direction) {
        switch (direction) {
            case DOWN:
                g.drawLine(getWidth() / 2, getHeight() / 2, getWidth() / 2, -getHeight());
                this.setConnectionOne(Direction.UP);
                this.setConnectionTwo(null);
                break;
            case LEFT:
                g.drawLine(getWidth() / 2, getHeight() / 2, getWidth(), getHeight() / 2);
                this.setConnectionOne(Direction.RIGHT);
                this.setConnectionTwo(null);
                break;
            case RIGHT:
                g.drawLine(0, getHeight() / 2, getWidth() / 2, getHeight() / 2);
                this.setConnectionOne(Direction.LEFT);
                this.setConnectionTwo(null);
                break;
            case UP:
                g.drawLine(getWidth() / 2, getHeight() / 2, getWidth() / 2, getHeight());
                this.setConnectionOne(Direction.DOWN);
                this.setConnectionTwo(null);
                break;
        }

    }

    private Direction connectedDirectionStartEnd(Tile mainTile, Tile connectedTile){
        int mainRow = mainTile.getRow();
        int mainCol = mainTile.getCol();
        int conRow = connectedTile.getRow();
        int conCol = connectedTile.getCol();

        if (mainRow == conRow && mainCol == conCol + 1){
            return Direction.RIGHT;
        }
        else if (mainRow == conRow && mainCol == conCol - 1){
            return Direction.LEFT;
        }
        else if (mainRow == conRow + 1 && mainCol == conCol){
            return Direction.DOWN;
        }
        return Direction.UP;
    }
}
